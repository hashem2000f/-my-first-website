#!/usr/bin/env python3
"""
سكريبت بسيط لتصدير المشروع كملف ZIP
"""

import os
import zipfile
import io
import datetime
import time

def collect_files():
    """تجميع جميع الملفات في المشروع باستثناء الملفات المجاهلة"""
    project_files = []
    
    # قائمة بالمجلدات والملفات التي سيتم استثنائها
    exclude_dirs = [
        '__pycache__',
        'venv',
        'env',
        'node_modules',
        '.git'
    ]
    exclude_files = [
        '.DS_Store',
        'Thumbs.db',
        'export_project.py'  # استثناء هذا السكريبت نفسه
    ]
    
    for root, dirs, files in os.walk('.'):
        # استثناء المجلدات المحددة
        dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
        
        for file in files:
            if file not in exclude_files and not file.endswith('.pyc'):
                file_path = os.path.join(root, file)
                # استبدال './' في بداية المسار
                if file_path.startswith('./'):
                    file_path = file_path[2:]
                
                # تخطي الملفات المخفية
                if os.path.basename(file_path).startswith('.'):
                    continue
                
                project_files.append(file_path)
    
    return project_files

def create_zip(files):
    """إنشاء ملف ZIP يحتوي على جميع ملفات المشروع"""
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    zip_filename = f'newsletter_automation_{timestamp}.zip'
    
    with zipfile.ZipFile(zip_filename, 'w') as zipf:
        for file in files:
            try:
                # تعيين تاريخ الملف إلى الوقت الحالي لتجنب مشكلة ما قبل 1980
                current_time = time.time()
                info = zipfile.ZipInfo(file)
                info.date_time = datetime.datetime.fromtimestamp(current_time).timetuple()[:6]
                info.compress_type = zipfile.ZIP_DEFLATED
                
                # قراءة الملف وكتابته في الأرشيف
                with open(file, 'rb') as f:
                    zipf.writestr(info, f.read())
                    
            except Exception as e:
                print(f"خطأ في إضافة الملف {file}: {e}")
    
    return zip_filename

def main():
    """الوظيفة الرئيسية للسكريبت"""
    print("بدء تصدير المشروع...")
    files = collect_files()
    print(f"تم العثور على {len(files)} ملف.")
    
    zip_file = create_zip(files)
    print(f"تم تصدير المشروع بنجاح إلى: {zip_file}")
    print(f"المسار الكامل: {os.path.abspath(zip_file)}")

if __name__ == '__main__':
    main()