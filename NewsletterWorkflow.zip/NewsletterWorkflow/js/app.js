/**
 * مدير الإشارات المرجعية
 * سكريبت إدارة الإشارات المرجعية مع دعم التخزين المحلي
 */

// تهيئة البيانات والعناصر
document.addEventListener('DOMContentLoaded', () => {
  // المتغيرات العامة
  const bookmarkForm = document.getElementById('bookmarkForm');
  const siteName = document.getElementById('siteName');
  const siteURL = document.getElementById('siteURL');
  const siteTags = document.getElementById('siteTags');
  const bookmarkItems = document.getElementById('bookmarkItems');
  const searchInput = document.getElementById('searchInput');
  const clearSearch = document.getElementById('clearSearch');
  const bookmarkCount = document.getElementById('bookmarkCount');
  const emptyState = document.getElementById('emptyState');
  const filterButtons = document.querySelectorAll('[data-filter]');
  
  // متغيرات الموديلات
  const editModal = new bootstrap.Modal(document.getElementById('editModal'));
  const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
  const toast = new bootstrap.Toast(document.getElementById('toast'), { delay: 3000 });
  
  // متغيرات عنصر التعديل
  const editForm = document.getElementById('editForm');
  const editId = document.getElementById('editId');
  const editName = document.getElementById('editName');
  const editURL = document.getElementById('editURL');
  const editNote = document.getElementById('editNote');
  const editFavorite = document.getElementById('editFavorite');
  
  // متغيرات تأكيد الحذف
  const deleteId = document.getElementById('deleteId');
  const confirmDelete = document.getElementById('confirmDelete');
  
  // متغير للفلترة الحالية
  let currentFilter = 'all';

  /**
   * تهيئة التطبيق
   */
  function initApp() {
    detectDeviceAndApplyTheme(); // تحديد نوع الجهاز وتطبيق السمة المناسبة
    displayBookmarks();
    setupEventListeners();
  }
  
  /**
   * تحديد نوع الجهاز وتطبيق السمة المناسبة
   */
  function detectDeviceAndApplyTheme() {
    const width = window.innerWidth;
    
    // تطبيق السمة حسب نوع الجهاز
    if (width <= 576) {
      // الهواتف - ذهبي
      applyTheme('gold');
    } else if (width <= 992) {
      // آيباد/التابلت - فضي
      applyTheme('silver');
    } else {
      // الكمبيوتر - أصفر
      applyTheme('yellow');
    }
  }
  
  /**
   * تطبيق السمة المحددة
   * @param {string} theme اسم السمة
   */
  function applyTheme(theme) {
    // إزالة جميع فئات السمات
    document.body.classList.remove('theme-yellow', 'theme-silver', 'theme-gold');
    
    // إضافة فئة السمة الجديدة
    document.body.classList.add(`theme-${theme}`);
  }

  /**
   * إعداد مستمعات الأحداث
   */
  function setupEventListeners() {
    // إضافة إشارة مرجعية جديدة
    bookmarkForm.addEventListener('submit', addBookmark);
    
    // البحث والتصفية
    searchInput.addEventListener('input', filterBookmarks);
    clearSearch.addEventListener('click', clearSearchInput);
    
    // أزرار التصفية
    filterButtons.forEach(button => {
      button.addEventListener('click', setFilter);
    });
    
    // مستمع حدث تغيير حجم النافذة لتطبيق السمة المناسبة للجهاز
    window.addEventListener('resize', () => {
      // إعادة تطبيق السمة عند تغيير حجم النافذة
      detectDeviceAndApplyTheme();
    });
    
    // حدث تعديل الإشارة المرجعية
    editForm.addEventListener('submit', saveEditedBookmark);
    
    // تأكيد الحذف
    confirmDelete.addEventListener('click', deleteBookmark);
  }

  /**
   * جلب الإشارات المرجعية من التخزين المحلي
   * @returns {Array} مصفوفة الإشارات المرجعية
   */
  function getBookmarks() {
    let bookmarks = localStorage.getItem('bookmarks');
    return bookmarks ? JSON.parse(bookmarks) : [];
  }

  /**
   * حفظ الإشارات المرجعية في التخزين المحلي
   * @param {Array} bookmarks مصفوفة الإشارات المرجعية
   */
  function saveBookmarks(bookmarks) {
    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
  }

  /**
   * إضافة إشارة مرجعية جديدة
   * @param {Event} e حدث النموذج
   */
  function addBookmark(e) {
    e.preventDefault();
    
    // التحقق من صحة URL
    if (!validateUrl(siteURL.value)) {
      showToast('الرجاء إدخال رابط صحيح يبدأ بـ http:// أو https://', 'danger');
      return false;
    }
    
    // إنشاء كائن الإشارة المرجعية
    const bookmark = {
      id: Date.now(),
      name: siteName.value,
      url: siteURL.value,
      note: siteTags.value,
      favorite: false,
      date: new Date().toISOString()
    };
    
    // إضافة الإشارة المرجعية للمصفوفة
    let bookmarks = getBookmarks();
    bookmarks.unshift(bookmark); // إضافة في البداية
    saveBookmarks(bookmarks);
    
    // إعادة تعيين النموذج وتحديث العرض
    bookmarkForm.reset();
    displayBookmarks();
    
    // عرض رسالة نجاح
    showToast('تمت إضافة الإشارة المرجعية بنجاح!', 'success');
    
    return false;
  }

  /**
   * عرض الإشارات المرجعية في واجهة المستخدم
   */
  function displayBookmarks() {
    // جلب الإشارات المرجعية المخزنة
    let bookmarks = getBookmarks();
    let filteredBookmarks = filterBookmarksBySearch(bookmarks);
    
    // تطبيق الفلتر الحالي (الكل / المفضلة)
    if (currentFilter === 'favorites') {
      filteredBookmarks = filteredBookmarks.filter(bookmark => bookmark.favorite);
    }
    
    // تحديث عداد الإشارات المرجعية
    bookmarkCount.textContent = bookmarks.length;
    
    // تفريغ قائمة الإشارات المرجعية
    bookmarkItems.innerHTML = '';
    
    // إظهار حالة فارغة إذا لم توجد إشارات مرجعية
    if (filteredBookmarks.length === 0) {
      if (searchInput.value) {
        bookmarkItems.innerHTML = `
          <div class="no-results">
            <i class="fas fa-search"></i>
            <h5>لا توجد نتائج للبحث</h5>
            <p>جرب كلمات بحث أخرى</p>
          </div>
        `;
      } else if (currentFilter === 'favorites') {
        bookmarkItems.innerHTML = `
          <div class="no-results">
            <i class="fas fa-star"></i>
            <h5>لا توجد إشارات مرجعية مفضلة</h5>
            <p>أضف إشارات مرجعية للمفضلة بالضغط على أيقونة النجمة</p>
          </div>
        `;
      } else {
        bookmarkItems.innerHTML = `
          <div class="no-results">
            <i class="fas fa-bookmark"></i>
            <h5>لا توجد إشارات مرجعية</h5>
            <p>أضف إشارة مرجعية جديدة باستخدام النموذج أعلاه</p>
          </div>
        `;
      }
      return;
    }
    
    // إنشاء عناصر الإشارات المرجعية وإضافتها للقائمة
    filteredBookmarks.forEach(bookmark => {
      const item = document.createElement('div');
      item.className = `list-group-item ${bookmark.favorite ? 'favorite-item' : ''}`;
      item.setAttribute('data-id', bookmark.id);
      item.draggable = true;
      
      // إنشاء محتوى الإشارة المرجعية
      item.innerHTML = `
        <div class="bookmark-content">
          <div class="drag-handle">
            <i class="fas fa-grip-lines"></i>
          </div>
          <button class="star-btn ${bookmark.favorite ? 'active' : ''}" aria-label="تفضيل">
            <i class="fas fa-star"></i>
          </button>
          <div class="bookmark-text">
            <a href="${bookmark.url}" target="_blank" rel="noopener noreferrer">${bookmark.name}</a>
            ${bookmark.note ? `<div class="note">${bookmark.note}</div>` : ''}
          </div>
        </div>
        <div class="bookmark-actions">
          <button class="btn btn-sm btn-outline-warning edit-btn" aria-label="تعديل">
            <i class="fas fa-edit"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger delete-btn" aria-label="حذف">
            <i class="fas fa-trash-alt"></i>
          </button>
        </div>
      `;
      
      // إضافة الإشارة المرجعية للقائمة
      bookmarkItems.appendChild(item);
      
      // إضافة تأثير العنصر الجديد
      if (bookmark.id === filteredBookmarks[0].id && !searchInput.value) {
        item.classList.add('new-item');
      }
      
      // إضافة مستمعات الأحداث للعناصر
      setupBookmarkItemEvents(item, bookmark.id);
    });
    
    // إعداد وظائف السحب والإسقاط
    setupDragAndDrop();
  }

  /**
   * إعداد مستمعات الأحداث لعنصر الإشارة المرجعية
   * @param {HTMLElement} item عنصر الإشارة المرجعية
   * @param {number} id معرف الإشارة المرجعية
   */
  function setupBookmarkItemEvents(item, id) {
    // زر التفضيل
    const starBtn = item.querySelector('.star-btn');
    starBtn.addEventListener('click', () => toggleFavorite(id));
    
    // زر التعديل
    const editBtn = item.querySelector('.edit-btn');
    editBtn.addEventListener('click', () => openEditModal(id));
    
    // زر الحذف
    const deleteBtn = item.querySelector('.delete-btn');
    deleteBtn.addEventListener('click', () => openDeleteModal(id));
  }

  /**
   * تبديل حالة التفضيل للإشارة المرجعية
   * @param {number} id معرف الإشارة المرجعية
   */
  function toggleFavorite(id) {
    let bookmarks = getBookmarks();
    
    // البحث عن الإشارة المرجعية وتغيير حالة التفضيل
    const index = bookmarks.findIndex(bookmark => bookmark.id === id);
    if (index !== -1) {
      bookmarks[index].favorite = !bookmarks[index].favorite;
      saveBookmarks(bookmarks);
      displayBookmarks();
      
      // عرض رسالة
      const action = bookmarks[index].favorite ? 'إضافة' : 'إزالة';
      showToast(`تم ${action} الإشارة المرجعية من المفضلة`, 'info');
    }
  }

  /**
   * فتح نافذة تعديل الإشارة المرجعية
   * @param {number} id معرف الإشارة المرجعية
   */
  function openEditModal(id) {
    const bookmarks = getBookmarks();
    const bookmark = bookmarks.find(bookmark => bookmark.id === id);
    
    if (bookmark) {
      // تعبئة النموذج بمعلومات الإشارة المرجعية
      editId.value = bookmark.id;
      editName.value = bookmark.name;
      editURL.value = bookmark.url;
      editNote.value = bookmark.note || '';
      editFavorite.checked = bookmark.favorite;
      
      // فتح النافذة
      editModal.show();
    }
  }

  /**
   * حفظ الإشارة المرجعية بعد التعديل
   * @param {Event} e حدث النموذج
   */
  function saveEditedBookmark(e) {
    e.preventDefault();
    
    // التحقق من صحة URL
    if (!validateUrl(editURL.value)) {
      showToast('الرجاء إدخال رابط صحيح يبدأ بـ http:// أو https://', 'danger');
      return;
    }
    
    const id = parseInt(editId.value);
    const bookmarks = getBookmarks();
    const index = bookmarks.findIndex(bookmark => bookmark.id === id);
    
    if (index !== -1) {
      // تحديث بيانات الإشارة المرجعية
      bookmarks[index].name = editName.value;
      bookmarks[index].url = editURL.value;
      bookmarks[index].note = editNote.value;
      bookmarks[index].favorite = editFavorite.checked;
      
      // حفظ التغييرات وتحديث العرض
      saveBookmarks(bookmarks);
      displayBookmarks();
      
      // إغلاق النافذة وإظهار رسالة
      editModal.hide();
      showToast('تم تحديث الإشارة المرجعية بنجاح!', 'success');
    }
  }

  /**
   * فتح نافذة تأكيد الحذف
   * @param {number} id معرف الإشارة المرجعية
   */
  function openDeleteModal(id) {
    deleteId.value = id;
    deleteModal.show();
  }

  /**
   * حذف الإشارة المرجعية
   */
  function deleteBookmark() {
    const id = parseInt(deleteId.value);
    let bookmarks = getBookmarks();
    
    // حذف الإشارة المرجعية من المصفوفة
    bookmarks = bookmarks.filter(bookmark => bookmark.id !== id);
    saveBookmarks(bookmarks);
    
    // تحديث العرض وإغلاق النافذة
    displayBookmarks();
    deleteModal.hide();
    
    // عرض رسالة
    showToast('تم حذف الإشارة المرجعية بنجاح', 'danger');
  }

  /**
   * إعداد وظائف السحب والإسقاط
   */
  function setupDragAndDrop() {
    const items = bookmarkItems.querySelectorAll('.list-group-item');
    let draggedItem = null;
    
    items.forEach(item => {
      // بدء السحب
      item.addEventListener('dragstart', function() {
        draggedItem = this;
        setTimeout(() => this.classList.add('dragging'), 0);
      });
      
      // انتهاء السحب
      item.addEventListener('dragend', function() {
        this.classList.remove('dragging');
        setTimeout(() => {
          // تحديث ترتيب الإشارات المرجعية في التخزين
          updateBookmarksOrder();
        }, 100);
      });
      
      // عند السحب فوق عنصر آخر
      item.addEventListener('dragover', function(e) {
        e.preventDefault();
        if (this !== draggedItem) {
          const rect = this.getBoundingClientRect();
          const mouseY = e.clientY;
          const threshold = rect.top + rect.height / 2;
          
          // تحديد موضع الإسقاط (قبل أو بعد العنصر)
          if (mouseY < threshold) {
            bookmarkItems.insertBefore(draggedItem, this);
          } else {
            bookmarkItems.insertBefore(draggedItem, this.nextSibling);
          }
        }
      });
    });
  }

  /**
   * تحديث ترتيب الإشارات المرجعية بعد السحب والإسقاط
   */
  function updateBookmarksOrder() {
    const items = bookmarkItems.querySelectorAll('.list-group-item');
    const bookmarks = getBookmarks();
    const newOrder = [];
    
    // إنشاء ترتيب جديد استنادًا إلى ترتيب العناصر في DOM
    items.forEach(item => {
      const id = parseInt(item.getAttribute('data-id'));
      const bookmark = bookmarks.find(bm => bm.id === id);
      if (bookmark) {
        newOrder.push(bookmark);
      }
    });
    
    // إضافة الإشارات المرجعية المفلترة (غير الظاهرة)
    bookmarks.forEach(bookmark => {
      if (!newOrder.some(b => b.id === bookmark.id)) {
        newOrder.push(bookmark);
      }
    });
    
    // حفظ الترتيب الجديد
    saveBookmarks(newOrder);
  }

  /**
   * تصفية الإشارات المرجعية حسب البحث
   * @param {Array} bookmarks مصفوفة الإشارات المرجعية
   * @returns {Array} مصفوفة الإشارات المرجعية المفلترة
   */
  function filterBookmarksBySearch(bookmarks) {
    const searchTerm = searchInput.value.toLowerCase();
    if (!searchTerm) return bookmarks;
    
    return bookmarks.filter(bookmark => {
      return (
        bookmark.name.toLowerCase().includes(searchTerm) ||
        bookmark.url.toLowerCase().includes(searchTerm) ||
        (bookmark.note && bookmark.note.toLowerCase().includes(searchTerm))
      );
    });
  }

  /**
   * تصفية الإشارات المرجعية (تحديث العرض)
   */
  function filterBookmarks() {
    displayBookmarks();
  }

  /**
   * مسح حقل البحث
   */
  function clearSearchInput() {
    searchInput.value = '';
    filterBookmarks();
  }

  /**
   * تعيين فلتر الإشارات المرجعية (الكل / المفضلة)
   * @param {Event} e حدث النقر
   */
  function setFilter(e) {
    // إزالة الفلتر النشط من جميع الأزرار
    filterButtons.forEach(btn => btn.classList.remove('active'));
    
    // تعيين الفلتر الجديد
    const button = e.currentTarget;
    button.classList.add('active');
    currentFilter = button.getAttribute('data-filter');
    
    // تحديث العرض
    displayBookmarks();
  }

  /**
   * التحقق من صحة URL
   * @param {string} url عنوان URL المراد التحقق منه
   * @returns {boolean} صحة URL
   */
  function validateUrl(url) {
    try {
      const pattern = /^(https?:\/\/)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/;
      return pattern.test(url);
    } catch (e) {
      return false;
    }
  }

  /**
   * إظهار رسالة توست
   * @param {string} message نص الرسالة
   * @param {string} type نوع الرسالة (success, danger, info, warning)
   */
  function showToast(message, type = 'success') {
    const toastElement = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    // تعيين لون الرسالة حسب النوع
    toastElement.classList.remove('bg-success', 'bg-danger', 'bg-info', 'bg-warning');
    toastElement.classList.add(`bg-${type}`);
    
    // تعيين نص الرسالة
    toastMessage.textContent = message;
    
    // إظهار الرسالة
    toast.show();
  }

  // بدء التطبيق
  initApp();
});
