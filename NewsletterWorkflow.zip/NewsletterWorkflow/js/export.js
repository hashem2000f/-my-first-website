/**
 * وظائف تصدير الإشارات المرجعية
 * يتيح تصدير الإشارات المرجعية بتنسيقات مختلفة
 */

document.addEventListener('DOMContentLoaded', () => {
  // عناصر التصدير
  const exportImageButton = document.getElementById('exportImage');
  const exportWordButton = document.getElementById('exportWord');
  const exportModal = new bootstrap.Modal(document.getElementById('exportModal'));

  // إضافة مستمعات الأحداث
  exportImageButton.addEventListener('click', exportAsImage);
  exportWordButton.addEventListener('click', exportAsWord);

  /**
   * تصدير الإشارات المرجعية كصورة
   */
  function exportAsImage() {
    const bookmarks = getBookmarksForExport();
    
    if (bookmarks.length === 0) {
      showExportError();
      return;
    }
    
    // إنشاء عنصر القماش المؤقت
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    // تحديد حجم القماش (تلقائي بناءً على عدد الإشارات المرجعية)
    const lineHeight = 30;
    const padding = 40;
    const titleHeight = 60;
    const footerHeight = 40;
    const itemMargin = 20;
    
    // حساب ارتفاع القماش بناءً على المحتوى
    let contentHeight = 0;
    bookmarks.forEach(bookmark => {
      let itemHeight = lineHeight * 2; // الاسم والرابط
      if (bookmark.note) {
        itemHeight += lineHeight; // الملاحظة
      }
      contentHeight += (itemHeight + itemMargin);
    });
    
    // تحديد أبعاد القماش
    canvas.width = 800;
    canvas.height = titleHeight + contentHeight + footerHeight + (padding * 2);
    
    // رسم الخلفية
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // تحديد خط العنوان
    ctx.fillStyle = '#3498db';
    ctx.font = 'bold 24px Arial';
    ctx.textAlign = 'center';
    
    // رسم العنوان
    ctx.fillText('إشاراتي المرجعية', canvas.width / 2, padding + 30);
    
    // رسم خط أفقي تحت العنوان
    ctx.strokeStyle = '#eeeeee';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(padding, titleHeight + padding/2);
    ctx.lineTo(canvas.width - padding, titleHeight + padding/2);
    ctx.stroke();
    
    // تحديد خط المحتوى
    ctx.fillStyle = '#333333';
    ctx.font = '16px Arial';
    ctx.textAlign = 'right';
    
    // رسم الإشارات المرجعية
    let y = titleHeight + padding;
    
    bookmarks.forEach((bookmark, index) => {
      // رسم المستطيل الخلفي
      if (bookmark.favorite) {
        ctx.fillStyle = '#fff8e1';
        ctx.fillRect(padding, y - 10, canvas.width - (padding * 2), lineHeight * (bookmark.note ? 3 : 2) + 10);
        
        // رسم نجمة للمفضلة
        ctx.fillStyle = '#f39c12';
        ctx.font = 'bold 16px Arial';
        ctx.fillText('★', canvas.width - padding - 20, y + 5);
        ctx.font = '16px Arial';
      }
      
      // اسم الموقع بخط عريض
      ctx.fillStyle = '#333333';
      ctx.font = 'bold 16px Arial';
      ctx.fillText(`${index + 1}. ${bookmark.name}`, canvas.width - padding, y);
      
      // رابط الموقع
      ctx.font = '14px Arial';
      ctx.fillStyle = '#3498db';
      y += lineHeight;
      ctx.fillText(bookmark.url, canvas.width - padding, y);
      
      // ملاحظة (إذا وجدت)
      if (bookmark.note) {
        ctx.fillStyle = '#777777';
        y += lineHeight;
        ctx.fillText(`ملاحظة: ${bookmark.note}`, canvas.width - padding, y);
      }
      
      // مسافة بين العناصر
      y += lineHeight;
    });
    
    // رسم التذييل
    ctx.fillStyle = '#999999';
    ctx.font = '12px Arial';
    ctx.textAlign = 'center';
    const today = new Date().toLocaleDateString('ar-EG');
    ctx.fillText(`تم تصديره من تطبيق مدير الإشارات المرجعية بتاريخ ${today}`, canvas.width / 2, canvas.height - padding);
    
    // تحويل القماش إلى صورة
    try {
      const imageData = canvas.toDataURL('image/png');
      
      // تنزيل الصورة
      downloadFile(imageData, 'bookmarks_export.png', 'image/png', true);
      
      // إغلاق نافذة التصدير
      exportModal.hide();
      
      // عرض رسالة نجاح
      showSuccessToast('تم تصدير الإشارات المرجعية كصورة بنجاح!');
    } catch (e) {
      console.error('خطأ في تصدير الصورة:', e);
      showExportError('حدث خطأ أثناء تصدير الصورة. يرجى المحاولة مرة أخرى.');
    }
  }

  /**
   * تصدير الإشارات المرجعية كملف وورد
   */
  function exportAsWord() {
    const bookmarks = getBookmarksForExport();
    
    if (bookmarks.length === 0) {
      showExportError();
      return;
    }
    
    // إنشاء HTML للتصدير كملف وورد
    let htmlContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta charset="utf-8">
        <title>إشاراتي المرجعية</title>
        <style>
          body {
            font-family: 'Segoe UI', Arial, sans-serif;
            direction: rtl;
          }
          h1 {
            color: #2b579a;
            text-align: center;
            border-bottom: 2px solid #eee;
            padding-bottom: 1rem;
            margin-bottom: 2rem;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 2rem;
          }
          th, td {
            padding: 12px;
            text-align: right;
            border: 1px solid #ddd;
          }
          th {
            background-color: #f8f9fa;
            font-weight: bold;
          }
          tr:nth-child(even) {
            background-color: #f8f9fa;
          }
          .site-name {
            font-weight: bold;
            color: #2b579a;
          }
          .site-url {
            color: #2c3e50;
            text-decoration: none;
          } 10px;
          }
          .bookmark {
            margin-bottom: 15px;
            padding: 10px;
            border-bottom: 1px solid #eee;
          }
          .bookmark-title {
            font-weight: bold;
            font-size: 16px;
            color: #333;
          }
          .bookmark-url {
            color: #0563c1;
            text-decoration: underline;
          }
          .bookmark-note {
            color: #666;
            font-style: italic;
            margin-top: 5px;
          }
          .favorite {
            background-color: #fffbeb;
          }
          .favorite .bookmark-title:before {
            content: "★ ";
            color: #ffc107;
          }
          .date {
            color: #999;
            font-size: 12px;
            margin-top: 5px;
          }
          .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 12px;
            color: #888;
            border-top: 1px solid #eee;
            padding-top: 15px;
          }
        </style>
      </head>
      <body>
        <h1>إشاراتي المرجعية</h1>
    `;
    
    // إضافة كل إشارة مرجعية
    bookmarks.forEach((bookmark, index) => {
      const date = new Date(bookmark.date).toLocaleDateString('ar-EG');
      htmlContent += `
        <div class="bookmark ${bookmark.favorite ? 'favorite' : ''}">
          <div class="bookmark-title">${index + 1}. ${escapeHTML(bookmark.name)}</div>
          <div class="bookmark-url">${escapeHTML(bookmark.url)}</div>
          ${bookmark.note ? `<div class="bookmark-note">ملاحظة: ${escapeHTML(bookmark.note)}</div>` : ''}
          <div class="date">تاريخ الإضافة: ${date}</div>
        </div>
      `;
    });
    
    // إضافة تذييل الصفحة
    htmlContent += `
        <div class="footer">
          تم تصديره من تطبيق مدير الإشارات المرجعية بتاريخ ${new Date().toLocaleDateString('ar-EG')}
        </div>
      </body>
      </html>
    `;
    
    // إضافة قالب XML المطلوب لفتح الملف في Microsoft Word
    const xmlTemplate = `
      <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
      <?mso-application progid="Word.Document"?>
    `;
    
    // دمج XML مع HTML
    const wordContent = xmlTemplate + htmlContent;
    
    // تنزيل الملف بامتداد .doc
    downloadFile(wordContent, 'bookmarks_export.doc', 'application/msword');
    
    // إغلاق نافذة التصدير
    exportModal.hide();
    
    // عرض رسالة نجاح
    showSuccessToast('تم تصدير الإشارات المرجعية كملف وورد بنجاح!');
  }

  /**
   * جلب الإشارات المرجعية بغرض التصدير
   * @returns {Array} مصفوفة الإشارات المرجعية
   */
  function getBookmarksForExport() {
    return localStorage.getItem('bookmarks') 
      ? JSON.parse(localStorage.getItem('bookmarks')) 
      : [];
  }

  /**
   * إنشاء وتنزيل ملف
   * @param {string} content محتوى الملف
   * @param {string} filename اسم الملف
   * @param {string} contentType نوع المحتوى
   * @param {boolean} isDataUrl يحدد ما إذا كان المحتوى هو بالفعل Data URL (للصور)
   */
  function downloadFile(content, filename, contentType, isDataUrl = false) {
    let url;
    
    if (isDataUrl) {
      // إذا كان المحتوى هو Data URL (صورة)، استخدمه مباشرة
      url = content;
    } else {
      // إنشاء Blob والحصول على URL له
      const blob = new Blob([content], { type: contentType });
      url = URL.createObjectURL(blob);
    }
    
    // إنشاء رابط للتنزيل وتفعيله
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    
    // تنظيف
    setTimeout(() => {
      document.body.removeChild(a);
      if (!isDataUrl) {
        URL.revokeObjectURL(url);
      }
    }, 100);
  }

  /**
   * عرض رسالة خطأ عند عدم وجود إشارات مرجعية للتصدير
   * @param {string} message رسالة الخطأ الاختيارية
   */
  function showExportError(message = 'لا توجد إشارات مرجعية للتصدير!') {
    // إنشاء توست خطأ
    const toastElement = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    toastElement.classList.remove('bg-success', 'bg-danger', 'bg-info', 'bg-warning');
    toastElement.classList.add('bg-danger');
    toastMessage.textContent = message;
    
    const toast = new bootstrap.Toast(toastElement, { delay: 3000 });
    toast.show();
    
    // إغلاق نافذة التصدير
    exportModal.hide();
  }
  
  /**
   * عرض رسالة نجاح
   * @param {string} message نص رسالة النجاح
   */
  function showSuccessToast(message) {
    const toastElement = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    toastElement.classList.remove('bg-success', 'bg-danger', 'bg-info', 'bg-warning');
    toastElement.classList.add('bg-success');
    toastMessage.textContent = message;
    
    const toast = new bootstrap.Toast(toastElement, { delay: 3000 });
    toast.show();
  }

  /**
   * تأمين النص لمنع ثغرات XSS
   * @param {string} text النص المراد تأمينه
   * @returns {string} النص بعد التأمين
   */
  function escapeHTML(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
});
