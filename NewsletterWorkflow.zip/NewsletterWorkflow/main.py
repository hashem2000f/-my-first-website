import os
import logging
from flask import Flask, render_template, request, jsonify, send_from_directory

# Настройка логирования
logging.basicConfig(level=logging.DEBUG)

# Создание Flask приложения
app = Flask(__name__, static_folder='.')
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key_for_development")

@app.route('/')
def index():
    """Маршрут для главной страницы"""
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    """Маршрут для обслуживания статических файлов"""
    return send_from_directory('.', path)

# API для автоматизации рабочих процессов между приложениями
@app.route('/api/workflows', methods=['GET'])
def get_workflows():
    """Получить список доступных рабочих процессов"""
    # Пример рабочих процессов
    workflows = [
        {"id": 1, "name": "Email Newsletter", "description": "Automatic email newsletter workflow"},
        {"id": 2, "name": "Social Media", "description": "Post to multiple social media platforms"},
        {"id": 3, "name": "Content Creation", "description": "Generate and schedule content"}
    ]
    return jsonify({"workflows": workflows})

@app.route('/api/workflows/<int:workflow_id>', methods=['GET'])
def get_workflow(workflow_id):
    """Получить информацию о конкретном рабочем процессе"""
    # Имитация получения данных
    workflow = {"id": workflow_id, "name": f"Workflow {workflow_id}", "steps": []}
    return jsonify(workflow)

@app.route('/api/ab-tests', methods=['GET'])
def get_ab_tests():
    """Получить список A/B тестов"""
    tests = [
        {"id": 1, "name": "Email Subject Line Test", "status": "active"},
        {"id": 2, "name": "Landing Page Layout Test", "status": "completed"}
    ]
    return jsonify({"tests": tests})

@app.route('/api/ab-tests', methods=['POST'])
def create_ab_test():
    """Создать новый A/B тест"""
    data = request.json
    # Здесь будет логика создания теста
    return jsonify({"success": True, "test_id": 3})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)