/**
 * Скрипт для функциональности автоматизации рабочих процессов
 */

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
  // Получение элементов DOM
  const workflowForm = document.getElementById('workflowForm');
  const newWorkflowModal = document.getElementById('workflowModal');
  const createWorkflowBtn = document.querySelector('#workflowModal .btn-primary');
  
  // Если элементы найдены, добавляем обработчики событий
  if (workflowForm && createWorkflowBtn) {
    createWorkflowBtn.addEventListener('click', createWorkflow);
  }
  
  // Загрузка рабочих процессов при загрузке страницы
  loadWorkflows();
  
  // Обработчики для кнопок действий
  document.addEventListener('click', function(e) {
    // Кнопки запуска рабочих процессов
    if (e.target.classList.contains('btn-primary') && e.target.closest('.workflow-card-actions')) {
      const workflowId = e.target.closest('.workflow-card').dataset.id;
      runWorkflow(workflowId);
    }
    
    // Кнопки редактирования рабочих процессов
    if (e.target.classList.contains('btn-outline-secondary') && e.target.closest('.workflow-card-actions')) {
      const workflowId = e.target.closest('.workflow-card').dataset.id;
      editWorkflow(workflowId);
    }
  });
});

/**
 * Загрузка рабочих процессов с сервера
 */
function loadWorkflows() {
  fetch('/api/workflows')
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        displayWorkflows(data.workflows);
      } else {
        console.error('Ошибка при загрузке рабочих процессов:', data.error);
      }
    })
    .catch(error => {
      console.error('Ошибка при загрузке рабочих процессов:', error);
    });
}

/**
 * Отображение рабочих процессов в интерфейсе
 * @param {Array} workflows Список рабочих процессов
 */
function displayWorkflows(workflows) {
  const workflowsContainer = document.querySelector('.row');
  
  if (!workflowsContainer) {
    console.error('Контейнер для рабочих процессов не найден');
    return;
  }
  
  // Если рабочих процессов нет, показываем сообщение
  if (workflows.length === 0) {
    workflowsContainer.innerHTML = `
      <div class="col-12">
        <div class="empty-state">
          <i class="fas fa-project-diagram"></i>
          <h4>Нет рабочих процессов</h4>
          <p>Создайте свой первый рабочий процесс, нажав кнопку "Создать рабочий процесс"</p>
        </div>
      </div>
    `;
    return;
  }
  
  // Очищаем контейнер перед добавлением новых элементов
  workflowsContainer.innerHTML = '';
  
  // Добавляем карточки рабочих процессов
  workflows.forEach(workflow => {
    const workflowCard = document.createElement('div');
    workflowCard.className = 'col-md-6 col-lg-4';
    workflowCard.innerHTML = `
      <div class="workflow-card" data-id="${workflow.id}">
        <div class="workflow-card-header">
          <h5 class="workflow-card-title">${workflow.name}</h5>
          <div class="dropdown">
            <button class="btn btn-sm" type="button" data-bs-toggle="dropdown">
              <i class="fas fa-ellipsis-v"></i>
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#"><i class="fas fa-edit me-2"></i> تعديل</a></li>
              <li><a class="dropdown-item" href="#"><i class="fas fa-copy me-2"></i> نسخ</a></li>
              <li><a class="dropdown-item text-danger" href="#"><i class="fas fa-trash-alt me-2"></i> حذف</a></li>
            </ul>
          </div>
        </div>
        <p class="workflow-card-description">${workflow.description || 'بدون وصف'}</p>
        <div class="workflow-card-actions">
          <button class="btn btn-sm btn-primary"><i class="fas fa-play me-1"></i> تشغيل</button>
          <button class="btn btn-sm btn-outline-secondary"><i class="fas fa-pencil-alt me-1"></i> تعديل</button>
        </div>
        <div class="workflow-card-footer">
          <div>
            ${getIntegrationTags(workflow.integrations)}
          </div>
          <span><i class="fas fa-calendar-alt me-1"></i> آخر تشغيل: ${getLastRunDate(workflow)}</span>
        </div>
      </div>
    `;
    
    workflowsContainer.appendChild(workflowCard);
  });
}

/**
 * Получение тегов интеграций для рабочего процесса
 * @param {Array} integrations Список интеграций
 * @returns {string} HTML-строка с тегами интеграций
 */
function getIntegrationTags(integrations) {
  if (!integrations || integrations.length === 0) {
    return '<span class="workflow-card-tag"><i class="fas fa-exclamation-circle"></i> بدون تكاملات</span>';
  }
  
  return integrations.map(integration => {
    let icon = 'fa-plug';
    
    // Определяем иконку в зависимости от типа интеграции
    if (integration.toLowerCase().includes('mailchimp')) {
      icon = 'fab fa-mailchimp';
    } else if (integration.toLowerCase().includes('wordpress')) {
      icon = 'fab fa-wordpress';
    } else if (integration.toLowerCase().includes('twitter')) {
      icon = 'fab fa-twitter';
    } else if (integration.toLowerCase().includes('facebook')) {
      icon = 'fab fa-facebook';
    }
    
    return `<span class="workflow-card-tag"><i class="${icon}"></i> ${integration}</span>`;
  }).join('');
}

/**
 * Получение даты последнего запуска рабочего процесса
 * @param {Object} workflow Объект рабочего процесса
 * @returns {string} Форматированная дата последнего запуска
 */
function getLastRunDate(workflow) {
  if (!workflow.last_run_date) {
    return 'لم يتم التشغيل بعد';
  }
  
  // В реальном приложении здесь будет форматирование даты
  return 'منذ يومين';
}

/**
 * Создание нового рабочего процесса
 */
function createWorkflow() {
  const workflowName = document.getElementById('workflowName').value;
  const workflowDescription = document.getElementById('workflowDescription').value;
  
  if (!workflowName) {
    alert('الرجاء إدخال اسم لسير العمل');
    return;
  }
  
  // Сбор данных о шагах рабочего процесса
  const steps = [];
  const stepElements = document.querySelectorAll('.step-container');
  
  stepElements.forEach((step, index) => {
    const stepType = step.querySelector('select').value;
    const stepName = step.querySelector('input').value;
    const stepConfig = step.querySelector('textarea').value;
    
    steps.push({
      position: index,
      name: stepName,
      step_type: stepType,
      config: stepConfig ? JSON.parse(stepConfig) : {}
    });
  });
  
  // Отправка данных на сервер
  fetch('/api/workflows', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: workflowName,
      description: workflowDescription,
      steps: steps
    })
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Закрыть модальное окно и обновить список рабочих процессов
      const bsModal = bootstrap.Modal.getInstance(document.getElementById('workflowModal'));
      bsModal.hide();
      
      // Очистить форму
      document.getElementById('workflowForm').reset();
      
      // Обновить список рабочих процессов
      loadWorkflows();
      
      // Показать уведомление об успешном создании
      showToast('تم إنشاء سير العمل بنجاح!', 'success');
    } else {
      alert('حدث خطأ أثناء إنشاء سير العمل: ' + data.error);
    }
  })
  .catch(error => {
    console.error('Ошибка при создании рабочего процесса:', error);
    alert('حدث خطأ أثناء إنشاء سير العمل. الرجاء المحاولة مرة أخرى.');
  });
}

/**
 * Запуск рабочего процесса
 * @param {number} workflowId Идентификатор рабочего процесса
 */
function runWorkflow(workflowId) {
  fetch(`/api/workflows/${workflowId}/run`, {
    method: 'POST'
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      showToast('تم بدء تشغيل سير العمل بنجاح!', 'success');
    } else {
      showToast('حدث خطأ أثناء تشغيل سير العمل: ' + data.error, 'danger');
    }
  })
  .catch(error => {
    console.error('Ошибка при запуске рабочего процесса:', error);
    showToast('حدث خطأ أثناء تشغيل سير العمل. الرجاء المحاولة مرة أخرى.', 'danger');
  });
}

/**
 * Редактирование рабочего процесса
 * @param {number} workflowId Идентификатор рабочего процесса
 */
function editWorkflow(workflowId) {
  // Получение данных о рабочем процессе
  fetch(`/api/workflows/${workflowId}`)
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        const workflow = data.workflow;
        
        // Заполнение формы данными рабочего процесса
        document.getElementById('workflowName').value = workflow.name;
        document.getElementById('workflowDescription').value = workflow.description || '';
        
        // В реальном приложении здесь будет заполнение шагов рабочего процесса
        
        // Показать модальное окно
        const bsModal = new bootstrap.Modal(document.getElementById('workflowModal'));
        bsModal.show();
      } else {
        showToast('حدث خطأ أثناء تحميل بيانات سير العمل: ' + data.error, 'danger');
      }
    })
    .catch(error => {
      console.error('Ошибка при загрузке данных рабочего процесса:', error);
      showToast('حدث خطأ أثناء تحميل بيانات سير العمل. الرجاء المحاولة مرة أخرى.', 'danger');
    });
}

/**
 * Показ уведомления
 * @param {string} message Текст уведомления
 * @param {string} type Тип уведомления (success, danger, info, warning)
 */
function showToast(message, type = 'success') {
  const toastContainer = document.querySelector('.toast-container');
  
  if (!toastContainer) {
    console.error('Контейнер для уведомлений не найден');
    return;
  }
  
  const toastElement = document.createElement('div');
  toastElement.className = `toast align-items-center text-white bg-${type} border-0`;
  toastElement.setAttribute('role', 'alert');
  toastElement.setAttribute('aria-live', 'assertive');
  toastElement.setAttribute('aria-atomic', 'true');
  
  toastElement.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'} me-2"></i>
        ${message}
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="إغلاق"></button>
    </div>
  `;
  
  toastContainer.appendChild(toastElement);
  
  const toast = new bootstrap.Toast(toastElement, { delay: 3000 });
  toast.show();
  
  // Удаление уведомления после скрытия
  toastElement.addEventListener('hidden.bs.toast', function() {
    toastContainer.removeChild(toastElement);
  });
}