/**
 * Скрипт для функциональности A/B тестирования
 */

document.addEventListener('DOMContentLoaded', function() {
  // Получение элементов DOM
  const newTestForm = document.getElementById('newTestForm');
  const createTestBtn = document.querySelector('#newTestModal .btn-primary');
  
  // Если элементы найдены, добавляем обработчики событий
  if (newTestForm && createTestBtn) {
    createTestBtn.addEventListener('click', createTest);
  }
  
  // Загрузка тестов при загрузке страницы
  loadTests();
  
  // Инициализация графиков в модальном окне результатов (если оно открыто)
  const resultsModal = document.getElementById('testResultsModal');
  if (resultsModal) {
    resultsModal.addEventListener('shown.bs.modal', function() {
      initializeCharts();
    });
  }
  
  // Обработчики для кнопок действий
  document.addEventListener('click', function(e) {
    // Кнопки деталей теста
    if (e.target.classList.contains('btn-outline-primary') && e.target.closest('.test-card')) {
      const testId = e.target.closest('.test-card').dataset.id;
      viewTestDetails(testId);
    }
    
    // Кнопки завершения теста
    if (e.target.classList.contains('btn-outline-success') && e.target.closest('.test-card')) {
      const testId = e.target.closest('.test-card').dataset.id;
      completeTest(testId);
    }
  });
});

/**
 * Загрузка A/B тестов с сервера
 */
function loadTests() {
  fetch('/api/ab-tests')
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        displayTests(data.tests);
      } else {
        console.error('Ошибка при загрузке тестов:', data.error);
      }
    })
    .catch(error => {
      console.error('Ошибка при загрузке тестов:', error);
    });
}

/**
 * Отображение A/B тестов в интерфейсе
 * @param {Array} tests Список тестов
 */
function displayTests(tests) {
  // Разделяем тесты по статусу
  const activeTests = tests.filter(test => test.status === 'active');
  const completedTests = tests.filter(test => test.status === 'completed');
  
  // Отображаем активные тесты
  displayTestsByStatus(activeTests, 'active');
  
  // Отображаем завершенные тесты
  displayTestsByStatus(completedTests, 'completed');
}

/**
 * Отображение тестов определенного статуса
 * @param {Array} tests Список тестов
 * @param {string} status Статус тестов
 */
function displayTestsByStatus(tests, status) {
  const container = document.querySelector(status === 'active' ? 
    '.row:nth-of-type(1)' : // Первый ряд для активных тестов
    '.row:nth-of-type(2)'   // Второй ряд для завершенных тестов
  );
  
  if (!container) {
    console.error(`Контейнер для тестов со статусом ${status} не найден`);
    return;
  }
  
  // Если тестов нет, показываем сообщение
  if (tests.length === 0) {
    container.innerHTML = `
      <div class="col-12">
        <div class="empty-state">
          <i class="fas fa-flask"></i>
          <h4>${status === 'active' ? 'لا توجد اختبارات نشطة' : 'لا توجد اختبارات مكتملة'}</h4>
          <p>${status === 'active' ? 'قم بإنشاء اختبار جديد باستخدام الزر أعلاه' : 'ستظهر الاختبارات المكتملة هنا'}</p>
        </div>
      </div>
    `;
    return;
  }
  
  // Очищаем контейнер перед добавлением новых элементов
  container.innerHTML = '';
  
  // Добавляем карточки тестов
  tests.forEach(test => {
    const testCard = document.createElement('div');
    testCard.className = 'col-md-6';
    testCard.innerHTML = createTestCardHTML(test);
    
    container.appendChild(testCard);
  });
}

/**
 * Создание HTML для карточки теста
 * @param {Object} test Объект теста
 * @returns {string} HTML-строка для карточки теста
 */
function createTestCardHTML(test) {
  // Определяем класс статуса
  let statusClass = 'test-status-draft';
  if (test.status === 'active') statusClass = 'test-status-active';
  if (test.status === 'completed') statusClass = 'test-status-completed';
  
  // Определяем текст статуса
  let statusText = 'مسودة';
  if (test.status === 'active') statusText = 'نشط';
  if (test.status === 'completed') statusText = 'مكتمل';
  
  // Создаем базовую структуру карточки
  let html = `
    <div class="test-card" data-id="${test.id}">
      <div class="test-card-header">
        <h5>${test.name}</h5>
        <span class="test-status ${statusClass}">${statusText}</span>
      </div>
      <p class="text-muted mb-3">${test.description || 'لا يوجد وصف'}</p>
  `;
  
  // Добавляем варианты
  if (test.variants && test.variants.length > 0) {
    const variantA = test.variants[0];
    const variantB = test.variants.length > 1 ? test.variants[1] : null;
    
    // Вариант A
    html += `
      <div class="variant-card variant-a mb-3">
        <h6>النسخة A${test.winner === 'A' ? ' <span class="winner-badge">الفائز</span>' : ''}</h6>
        <p class="mb-2">${variantA.name || variantA.content || 'النسخة A'}</p>
        <div class="d-flex justify-content-between">
    `;
    
    // Метрики для варианта A
    if (test.status === 'active' || test.status === 'completed') {
      html += `
          <span><i class="fas fa-eye me-1"></i> معدل الفتح: ${variantA.open_rate || variantA.conversion_rate || '0'}%</span>
          <span><i class="fas fa-mouse-pointer me-1"></i> معدل النقر: ${variantA.click_rate || '0'}%</span>
      `;
    } else {
      html += `<span>لم يتم بدء الاختبار بعد</span>`;
    }
    
    html += `
        </div>
      </div>
    `;
    
    // Вариант B
    if (variantB) {
      html += `
        <div class="variant-card variant-b">
          <h6>النسخة B${test.winner === 'B' ? ' <span class="winner-badge">الفائز</span>' : ''}</h6>
          <p class="mb-2">${variantB.name || variantB.content || 'النسخة B'}</p>
          <div class="d-flex justify-content-between">
      `;
      
      // Метрики для варианта B
      if (test.status === 'active' || test.status === 'completed') {
        html += `
            <span><i class="fas fa-eye me-1"></i> معدل الفتح: ${variantB.open_rate || variantB.conversion_rate || '0'}%</span>
            <span><i class="fas fa-mouse-pointer me-1"></i> معدل النقر: ${variantB.click_rate || '0'}%</span>
        `;
      } else {
        html += `<span>لم يتم بدء الاختبار بعد</span>`;
      }
      
      html += `
          </div>
        </div>
      `;
    }
  } else {
    html += `<p>لا توجد نسخ في هذا الاختبار</p>`;
  }
  
  // Добавляем кнопки действий
  html += `
    <div class="mt-3 d-flex justify-content-end">
      <button class="btn btn-sm btn-outline-primary me-2">
        <i class="fas fa-chart-pie me-1"></i> تفاصيل
      </button>
  `;
  
  if (test.status === 'active') {
    html += `
      <button class="btn btn-sm btn-outline-success">
        <i class="fas fa-check me-1"></i> إنهاء الاختبار
      </button>
    `;
  }
  
  html += `
    </div>
  </div>
  `;
  
  return html;
}

/**
 * Создание нового A/B теста
 */
function createTest() {
  // Собираем данные формы
  const testName = document.getElementById('testName').value;
  const testDescription = document.getElementById('testDescription').value;
  const testType = document.getElementById('testType').value;
  const audienceSize = document.getElementById('audienceSize').value;
  const successMetric = document.getElementById('successMetric').value;
  const testDuration = document.getElementById('testDuration').value;
  
  // Данные для вариантов
  const variantAName = document.getElementById('variantAName').value;
  const variantAContent = document.getElementById('variantAContent').value;
  const variantBName = document.getElementById('variantBName').value;
  const variantBContent = document.getElementById('variantBContent').value;
  
  // Проверка заполнения обязательных полей
  if (!testName) {
    alert('الرجاء إدخال اسم للاختبار');
    return;
  }
  
  if (!variantAContent || !variantBContent) {
    alert('الرجاء إدخال محتوى للنسختين A و B');
    return;
  }
  
  // Создаем объект теста
  const testData = {
    name: testName,
    description: testDescription,
    status: 'draft', // По умолчанию создаем в статусе "draft"
    audience_size: parseInt(audienceSize),
    test_type: testType,
    success_metric: successMetric,
    duration: parseInt(testDuration),
    variants: [
      {
        name: variantAName || 'النسخة A',
        content: variantAContent
      },
      {
        name: variantBName || 'النسخة B',
        content: variantBContent
      }
    ]
  };
  
  // Отправляем данные на сервер
  fetch('/api/ab-tests', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(testData)
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Закрываем модальное окно
      const bsModal = bootstrap.Modal.getInstance(document.getElementById('newTestModal'));
      bsModal.hide();
      
      // Очищаем форму
      document.getElementById('newTestForm').reset();
      
      // Обновляем список тестов
      loadTests();
      
      // Показываем сообщение об успехе
      showToast('تم إنشاء الاختبار بنجاح!', 'success');
    } else {
      alert('حدث خطأ أثناء إنشاء الاختبار: ' + data.error);
    }
  })
  .catch(error => {
    console.error('Ошибка при создании теста:', error);
    alert('حدث خطأ أثناء إنشاء الاختبار. الرجاء المحاولة مرة أخرى.');
  });
}

/**
 * Просмотр деталей теста
 * @param {number} testId Идентификатор теста
 */
function viewTestDetails(testId) {
  fetch(`/api/ab-tests/${testId}`)
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        const test = data.test;
        
        // Заполняем модальное окно данными теста
        const modalTitle = document.querySelector('#testResultsModal .modal-title');
        if (modalTitle) modalTitle.textContent = `نتائج ${test.name}`;
        
        // Открываем модальное окно
        const resultsModal = new bootstrap.Modal(document.getElementById('testResultsModal'));
        resultsModal.show();
        
        // Инициализируем графики
        initializeCharts(test);
      } else {
        showToast('حدث خطأ أثناء تحميل نتائج الاختبار: ' + data.error, 'danger');
      }
    })
    .catch(error => {
      console.error('Ошибка при загрузке деталей теста:', error);
      showToast('حدث خطأ أثناء تحميل نتائج الاختبار. الرجاء المحاولة مرة أخرى.', 'danger');
    });
}

/**
 * Инициализация графиков для отображения результатов теста
 * @param {Object} test Объект теста (если есть)
 */
function initializeCharts(test) {
  // Используем тестовые данные, если нет реальных данных
  const openRateData = [32, 28];
  const clickRateData = [5.2, 6.8];
  
  // Если есть данные теста, используем их
  if (test && test.variants && test.variants.length >= 2) {
    const variantA = test.variants[0];
    const variantB = test.variants[1];
    
    if (variantA.open_rate && variantB.open_rate) {
      openRateData[0] = variantA.open_rate;
      openRateData[1] = variantB.open_rate;
    }
    
    if (variantA.click_rate && variantB.click_rate) {
      clickRateData[0] = variantA.click_rate;
      clickRateData[1] = variantB.click_rate;
    }
  }
  
  // Инициализация графика для показателя открытий
  const openRateCtx = document.getElementById('openRateChart').getContext('2d');
  if (window.openRateChart) {
    window.openRateChart.destroy();
  }
  
  window.openRateChart = new Chart(openRateCtx, {
    type: 'bar',
    data: {
      labels: ['النسخة A', 'النسخة B'],
      datasets: [{
        label: 'معدل الفتح',
        data: openRateData,
        backgroundColor: [
          'rgba(52, 152, 219, 0.7)',
          'rgba(243, 156, 18, 0.7)'
        ],
        borderColor: [
          'rgba(52, 152, 219, 1)',
          'rgba(243, 156, 18, 1)'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          max: Math.max(...openRateData) * 1.2, // Максимальное значение + 20%
          ticks: {
            callback: function(value) {
              return value + '%';
            }
          }
        }
      },
      plugins: {
        tooltip: {
          callbacks: {
            label: function(context) {
              return context.parsed.y + '%';
            }
          }
        }
      }
    }
  });
  
  // Инициализация графика для показателя кликов
  const clickRateCtx = document.getElementById('clickRateChart').getContext('2d');
  if (window.clickRateChart) {
    window.clickRateChart.destroy();
  }
  
  window.clickRateChart = new Chart(clickRateCtx, {
    type: 'bar',
    data: {
      labels: ['النسخة A', 'النسخة B'],
      datasets: [{
        label: 'معدل النقر',
        data: clickRateData,
        backgroundColor: [
          'rgba(52, 152, 219, 0.7)',
          'rgba(243, 156, 18, 0.7)'
        ],
        borderColor: [
          'rgba(52, 152, 219, 1)',
          'rgba(243, 156, 18, 1)'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          max: Math.max(...clickRateData) * 1.2, // Максимальное значение + 20%
          ticks: {
            callback: function(value) {
              return value + '%';
            }
          }
        }
      },
      plugins: {
        tooltip: {
          callbacks: {
            label: function(context) {
              return context.parsed.y + '%';
            }
          }
        }
      }
    }
  });
}

/**
 * Завершение A/B теста
 * @param {number} testId Идентификатор теста
 */
function completeTest(testId) {
  if (!confirm('هل أنت متأكد من رغبتك في إنهاء هذا الاختبار؟')) {
    return;
  }
  
  fetch(`/api/ab-tests/${testId}/stop`, {
    method: 'POST'
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Обновляем список тестов
      loadTests();
      
      // Показываем сообщение об успехе
      showToast('تم إنهاء الاختبار بنجاح!', 'success');
    } else {
      showToast('حدث خطأ أثناء إنهاء الاختبار: ' + data.error, 'danger');
    }
  })
  .catch(error => {
    console.error('Ошибка при завершении теста:', error);
    showToast('حدث خطأ أثناء إنهاء الاختبار. الرجاء المحاولة مرة أخرى.', 'danger');
  });
}

/**
 * Показ уведомления
 * @param {string} message Текст уведомления
 * @param {string} type Тип уведомления (success, danger, info, warning)
 */
function showToast(message, type = 'success') {
  const toastContainer = document.querySelector('.toast-container');
  
  if (!toastContainer) {
    console.error('Контейнер для уведомлений не найден');
    return;
  }
  
  const toastElement = document.createElement('div');
  toastElement.className = `toast align-items-center text-white bg-${type} border-0`;
  toastElement.setAttribute('role', 'alert');
  toastElement.setAttribute('aria-live', 'assertive');
  toastElement.setAttribute('aria-atomic', 'true');
  
  toastElement.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'} me-2"></i>
        ${message}
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="إغلاق"></button>
    </div>
  `;
  
  toastContainer.appendChild(toastElement);
  
  const toast = new bootstrap.Toast(toastElement, { delay: 3000 });
  toast.show();
  
  // Удаление уведомления после скрытия
  toastElement.addEventListener('hidden.bs.toast', function() {
    toastContainer.removeChild(toastElement);
  });
}