from flask import jsonify, request, send_from_directory
from app import app
from models import db, Workflow, WorkflowStep, Integration, ABTest, ABTestVariant
from datetime import datetime

@app.route('/')
def index():
    """Маршрут для главной страницы"""
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    """Маршрут для обслуживания статических файлов"""
    return send_from_directory('.', path)

# API для рабочих процессов
@app.route('/api/workflows', methods=['GET'])
def get_workflows():
    """Получить список рабочих процессов"""
    workflows = Workflow.query.all()
    return jsonify({
        'success': True,
        'workflows': [workflow.to_dict() for workflow in workflows]
    })

@app.route('/api/workflows', methods=['POST'])
def create_workflow():
    """Создать новый рабочий процесс"""
    data = request.json
    try:
        workflow = Workflow(
            name=data.get('name'),
            description=data.get('description', '')
        )
        db.session.add(workflow)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'workflow': workflow.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

@app.route('/api/workflows/<int:workflow_id>', methods=['GET'])
def get_workflow(workflow_id):
    """Получить информацию о конкретном рабочем процессе"""
    workflow = Workflow.query.get_or_404(workflow_id)
    return jsonify({
        'success': True,
        'workflow': workflow.to_dict()
    })

@app.route('/api/workflows/<int:workflow_id>', methods=['PUT'])
def update_workflow(workflow_id):
    """Обновить рабочий процесс"""
    workflow = Workflow.query.get_or_404(workflow_id)
    data = request.json
    
    try:
        if 'name' in data:
            workflow.name = data['name']
        if 'description' in data:
            workflow.description = data['description']
            
        workflow.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'workflow': workflow.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

@app.route('/api/workflows/<int:workflow_id>', methods=['DELETE'])
def delete_workflow(workflow_id):
    """Удалить рабочий процесс"""
    workflow = Workflow.query.get_or_404(workflow_id)
    
    try:
        db.session.delete(workflow)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Workflow {workflow_id} has been deleted'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

# API для шагов рабочего процесса
@app.route('/api/workflows/<int:workflow_id>/steps', methods=['POST'])
def add_workflow_step(workflow_id):
    """Добавить шаг в рабочий процесс"""
    workflow = Workflow.query.get_or_404(workflow_id)
    data = request.json
    
    try:
        step = WorkflowStep(
            workflow_id=workflow_id,
            name=data.get('name'),
            description=data.get('description', ''),
            step_type=data.get('step_type'),
            config=data.get('config', {}),
            position=data.get('position', 0)
        )
        
        db.session.add(step)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'step': step.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

# API для A/B тестов
@app.route('/api/ab-tests', methods=['GET'])
def get_ab_tests():
    """Получить список A/B тестов"""
    tests = ABTest.query.all()
    return jsonify({
        'success': True,
        'tests': [test.to_dict() for test in tests]
    })

@app.route('/api/ab-tests', methods=['POST'])
def create_ab_test():
    """Создать новый A/B тест"""
    data = request.json
    
    try:
        test = ABTest(
            name=data.get('name'),
            description=data.get('description', ''),
            status=data.get('status', 'draft')
        )
        
        # Добавление вариантов теста
        variants_data = data.get('variants', [])
        for variant_data in variants_data:
            variant = ABTestVariant(
                name=variant_data.get('name'),
                content=variant_data.get('content', '')
            )
            test.variants.append(variant)
        
        db.session.add(test)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'test': test.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

@app.route('/api/ab-tests/<int:test_id>', methods=['GET'])
def get_ab_test(test_id):
    """Получить информацию о конкретном A/B тесте"""
    test = ABTest.query.get_or_404(test_id)
    return jsonify({
        'success': True,
        'test': test.to_dict()
    })

@app.route('/api/ab-tests/<int:test_id>/start', methods=['POST'])
def start_ab_test(test_id):
    """Запустить A/B тест"""
    test = ABTest.query.get_or_404(test_id)
    
    try:
        test.status = 'active'
        test.start_date = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'A/B Test {test_id} has been started',
            'test': test.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

@app.route('/api/ab-tests/<int:test_id>/stop', methods=['POST'])
def stop_ab_test(test_id):
    """Остановить A/B тест"""
    test = ABTest.query.get_or_404(test_id)
    
    try:
        test.status = 'completed'
        test.end_date = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'A/B Test {test_id} has been completed',
            'test': test.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

# API для интеграций
@app.route('/api/integrations', methods=['GET'])
def get_integrations():
    """Получить список доступных интеграций"""
    integrations = Integration.query.all()
    return jsonify({
        'success': True,
        'integrations': [integration.to_dict() for integration in integrations]
    })

@app.route('/api/integrations', methods=['POST'])
def create_integration():
    """Создать новую интеграцию"""
    data = request.json
    
    try:
        integration = Integration(
            name=data.get('name'),
            service_type=data.get('service_type'),
            config=data.get('config', {})
        )
        
        db.session.add(integration)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'integration': integration.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400