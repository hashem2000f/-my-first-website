import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from models import db

# Настройка логирования
logging.basicConfig(level=logging.DEBUG)

# Создание Flask приложения
app = Flask(__name__, static_folder='.')
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key_for_development")

# Настройка базы данных
database_url = os.environ.get("DATABASE_URL", "sqlite:///newsletter_automation.db")
app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Инициализация базы данных
db.init_app(app)

# Создание таблиц базы данных
with app.app_context():
    db.create_all()

# Импорт маршрутов
from routes import *