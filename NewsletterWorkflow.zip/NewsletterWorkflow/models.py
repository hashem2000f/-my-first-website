from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Workflow(db.Model):
    """Модель рабочего процесса"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Связь с интеграциями
    integrations = db.relationship('Integration', secondary='workflow_integration', backref='workflows')
    
    # Связь с шагами рабочего процесса
    steps = db.relationship('WorkflowStep', backref='workflow', cascade='all, delete-orphan')
    
    def to_dict(self):
        """Преобразование модели в словарь"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'steps': [step.to_dict() for step in self.steps],
            'integrations': [integration.name for integration in self.integrations]
        }

class WorkflowStep(db.Model):
    """Модель шага рабочего процесса"""
    id = db.Column(db.Integer, primary_key=True)
    workflow_id = db.Column(db.Integer, db.ForeignKey('workflow.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    step_type = db.Column(db.String(50), nullable=False)
    config = db.Column(db.JSON)
    position = db.Column(db.Integer, default=0)
    
    def to_dict(self):
        """Преобразование модели в словарь"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'step_type': self.step_type,
            'config': self.config,
            'position': self.position
        }

class Integration(db.Model):
    """Модель интеграции с внешними сервисами"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    service_type = db.Column(db.String(50), nullable=False)
    config = db.Column(db.JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        """Преобразование модели в словарь"""
        return {
            'id': self.id,
            'name': self.name,
            'service_type': self.service_type,
            'created_at': self.created_at.isoformat()
        }

# Таблица связи между рабочими процессами и интеграциями
workflow_integration = db.Table('workflow_integration',
    db.Column('workflow_id', db.Integer, db.ForeignKey('workflow.id'), primary_key=True),
    db.Column('integration_id', db.Integer, db.ForeignKey('integration.id'), primary_key=True)
)

class ABTest(db.Model):
    """Модель A/B теста"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    status = db.Column(db.String(20), default='draft')  # draft, active, paused, completed
    start_date = db.Column(db.DateTime)
    end_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Связь с вариантами теста
    variants = db.relationship('ABTestVariant', backref='test', cascade='all, delete-orphan')
    
    def to_dict(self):
        """Преобразование модели в словарь"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'status': self.status,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'created_at': self.created_at.isoformat(),
            'variants': [variant.to_dict() for variant in self.variants]
        }

class ABTestVariant(db.Model):
    """Модель варианта A/B теста"""
    id = db.Column(db.Integer, primary_key=True)
    test_id = db.Column(db.Integer, db.ForeignKey('ab_test.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text)
    conversion_rate = db.Column(db.Float, default=0)
    impressions = db.Column(db.Integer, default=0)
    conversions = db.Column(db.Integer, default=0)
    
    def to_dict(self):
        """Преобразование модели в словарь"""
        return {
            'id': self.id,
            'name': self.name,
            'content': self.content,
            'conversion_rate': self.conversion_rate,
            'impressions': self.impressions,
            'conversions': self.conversions
        }