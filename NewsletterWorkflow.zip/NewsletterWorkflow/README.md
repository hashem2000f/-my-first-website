# أتمتة النشرات الإخبارية

تطبيق لمساعدة ناشري النشرات الإخبارية على إنشاء سير عمل مخصص بين تطبيقاتهم المفضلة، مع إمكانيات اختبار A/B.

## المميزات

- ✅ إنشاء وإدارة سير العمل بين التطبيقات المختلفة
- ✅ اختبارات A/B للنشرات الإخبارية (عناوين، محتوى، أوقات إرسال)
- ✅ تحليلات وإحصائيات مفصلة
- ✅ واجهة مستخدم باللغة العربية
- ✅ التكامل مع خدمات بريد إلكتروني متعددة

## متطلبات النظام

- Python 3.11 أو أحدث
- Flask
- SQLAlchemy
- قاعدة بيانات (PostgreSQL أو SQLite)
- متصفح حديث

## تثبيت المشروع

### 1. استنساخ المستودع

```bash
git clone https://github.com/yourusername/newsletter-automation.git
cd newsletter-automation
```

### 2. إنشاء بيئة افتراضية وتثبيت المتطلبات

```bash
python -m venv venv
source venv/bin/activate  # على نظام Linux/Mac
venv\Scripts\activate  # على نظام Windows
pip install -r requirements.txt
```

### 3. إعداد قاعدة البيانات

```bash
export DATABASE_URL="postgresql://username:password@localhost/newsletter_db"  # Linux/Mac
set DATABASE_URL=postgresql://username:password@localhost/newsletter_db  # Windows
```

### 4. تشغيل التطبيق

```bash
python main.py
```

بعد ذلك، يمكنك الوصول إلى التطبيق عبر المتصفح على العنوان: `http://localhost:5000`

## هيكل المشروع

```
newsletter-automation/
├── app.py                 # مكونات تطبيق Flask
├── models.py              # نماذج قاعدة البيانات
├── routes.py              # مسارات API
├── main.py                # نقطة الدخول الرئيسية
├── static/                # الملفات الثابتة
│   ├── css/               # ملفات CSS
│   └── js/                # ملفات JavaScript
├── js/                    # سكريبتات إضافية
├── templates/             # قوالب HTML
├── tests/                 # اختبارات
└── .vscode/               # إعدادات Visual Studio Code
```

## كيفية المساهمة

1. قم بإنشاء نسخة متفرعة (Fork) من المشروع
2. قم بإنشاء فرع ميزات جديد (`git checkout -b feature/amazing-feature`)
3. قم بتنفيذ التغييرات الخاصة بك (`git commit -m 'إضافة ميزة مذهلة'`)
4. قم بدفع التغييرات إلى الفرع (`git push origin feature/amazing-feature`)
5. قم بفتح طلب سحب (Pull Request)

## ترخيص

هذا المشروع مرخص تحت رخصة MIT - انظر ملف `LICENSE` للتفاصيل.

## الاتصال

اسم المؤلف - [@yourtwitter](https://twitter.com/yourtwitter) - email@example.com